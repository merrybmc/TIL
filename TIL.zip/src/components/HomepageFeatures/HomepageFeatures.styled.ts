import styled from 'styled-components';
export const FeatureBox = styled.section`
  background-color: #ffffff;
`;
