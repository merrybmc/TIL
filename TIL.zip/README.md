# Meta 오픈 소스 docusaurus를 활용한 TIL 블로그

<h3> 🚀 Stack</h3>
<p>js, ts, css, github-Pages, github-Actions</p>
