import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/TIL/__docusaurus/debug',
    component: ComponentCreator('/TIL/__docusaurus/debug', 'e42'),
    exact: true
  },
  {
    path: '/TIL/__docusaurus/debug/config',
    component: ComponentCreator('/TIL/__docusaurus/debug/config', '853'),
    exact: true
  },
  {
    path: '/TIL/__docusaurus/debug/content',
    component: ComponentCreator('/TIL/__docusaurus/debug/content', 'c9d'),
    exact: true
  },
  {
    path: '/TIL/__docusaurus/debug/globalData',
    component: ComponentCreator('/TIL/__docusaurus/debug/globalData', '414'),
    exact: true
  },
  {
    path: '/TIL/__docusaurus/debug/metadata',
    component: ComponentCreator('/TIL/__docusaurus/debug/metadata', 'eb0'),
    exact: true
  },
  {
    path: '/TIL/__docusaurus/debug/registry',
    component: ComponentCreator('/TIL/__docusaurus/debug/registry', '68a'),
    exact: true
  },
  {
    path: '/TIL/__docusaurus/debug/routes',
    component: ComponentCreator('/TIL/__docusaurus/debug/routes', '7d9'),
    exact: true
  },
  {
    path: '/TIL/docs',
    component: ComponentCreator('/TIL/docs', '23a'),
    routes: [
      {
        path: '/TIL/docs/frontend/CSS/가상 클래스 선택자',
        component: ComponentCreator('/TIL/docs/frontend/CSS/가상 클래스 선택자', '39e'),
        exact: true,
        sidebar: "frontend"
      },
      {
        path: '/TIL/docs/frontend/CSS/텍스트 꾸미기',
        component: ComponentCreator('/TIL/docs/frontend/CSS/텍스트 꾸미기', 'a89'),
        exact: true,
        sidebar: "frontend"
      },
      {
        path: '/TIL/docs/frontend/CSS/CSS 단위',
        component: ComponentCreator('/TIL/docs/frontend/CSS/CSS 단위', 'ffb'),
        exact: true,
        sidebar: "frontend"
      },
      {
        path: '/TIL/docs/frontend/CSS/CSS 선택자',
        component: ComponentCreator('/TIL/docs/frontend/CSS/CSS 선택자', '162'),
        exact: true,
        sidebar: "frontend"
      },
      {
        path: '/TIL/docs/frontend/CSS/CSS 적용 방법',
        component: ComponentCreator('/TIL/docs/frontend/CSS/CSS 적용 방법', '62a'),
        exact: true,
        sidebar: "frontend"
      },
      {
        path: '/TIL/docs/frontend/CSS/CSS Box 모델',
        component: ComponentCreator('/TIL/docs/frontend/CSS/CSS Box 모델', 'ef3'),
        exact: true,
        sidebar: "frontend"
      },
      {
        path: '/TIL/docs/frontend/CSS/display 속성',
        component: ComponentCreator('/TIL/docs/frontend/CSS/display 속성', '41f'),
        exact: true,
        sidebar: "frontend"
      },
      {
        path: '/TIL/docs/frontend/CSS/Flex',
        component: ComponentCreator('/TIL/docs/frontend/CSS/Flex', '590'),
        exact: true,
        sidebar: "frontend"
      },
      {
        path: '/TIL/docs/frontend/CSS/Grid',
        component: ComponentCreator('/TIL/docs/frontend/CSS/Grid', '1a7'),
        exact: true,
        sidebar: "frontend"
      },
      {
        path: '/TIL/docs/frontend/CSS/position 속성',
        component: ComponentCreator('/TIL/docs/frontend/CSS/position 속성', '8c3'),
        exact: true,
        sidebar: "frontend"
      },
      {
        path: '/TIL/docs/frontend/CSS/SVG',
        component: ComponentCreator('/TIL/docs/frontend/CSS/SVG', '3aa'),
        exact: true,
        sidebar: "frontend"
      },
      {
        path: '/TIL/docs/frontend/HTML/목록 태그',
        component: ComponentCreator('/TIL/docs/frontend/HTML/목록 태그', 'ab5'),
        exact: true,
        sidebar: "frontend"
      },
      {
        path: '/TIL/docs/frontend/HTML/블록 인라인 레벨 요소',
        component: ComponentCreator('/TIL/docs/frontend/HTML/블록 인라인 레벨 요소', '9b0'),
        exact: true,
        sidebar: "frontend"
      },
      {
        path: '/TIL/docs/frontend/HTML/텍스트 태그',
        component: ComponentCreator('/TIL/docs/frontend/HTML/텍스트 태그', 'ee5'),
        exact: true,
        sidebar: "frontend"
      },
      {
        path: '/TIL/docs/frontend/HTML/HTML 문서 구조',
        component: ComponentCreator('/TIL/docs/frontend/HTML/HTML 문서 구조', '264'),
        exact: true,
        sidebar: "frontend"
      },
      {
        path: '/TIL/docs/frontend/intro',
        component: ComponentCreator('/TIL/docs/frontend/intro', '4b9'),
        exact: true,
        sidebar: "frontend"
      },
      {
        path: '/TIL/docs/frontend/Javascript/함수',
        component: ComponentCreator('/TIL/docs/frontend/Javascript/함수', 'd05'),
        exact: true,
        sidebar: "frontend"
      },
      {
        path: '/TIL/docs/frontend/Typescript/타입',
        component: ComponentCreator('/TIL/docs/frontend/Typescript/타입', 'aea'),
        exact: true,
        sidebar: "frontend"
      },
      {
        path: '/TIL/docs/frontend/Typescript/타입시스템',
        component: ComponentCreator('/TIL/docs/frontend/Typescript/타입시스템', '147'),
        exact: true,
        sidebar: "frontend"
      }
    ]
  },
  {
    path: '/TIL/',
    component: ComponentCreator('/TIL/', '8e1'),
    exact: true
  },
  {
    path: '*',
    component: ComponentCreator('*'),
  },
];
