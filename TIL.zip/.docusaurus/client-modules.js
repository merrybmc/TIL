export default [
  require('C:\\Users\\User\\Desktop\\TIL\\node_modules\\infima\\dist\\css\\default\\default.css'),
  require('C:\\Users\\User\\Desktop\\TIL\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages'),
  require('C:\\Users\\User\\Desktop\\TIL\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress'),
  require('C:\\Users\\User\\Desktop\\TIL\\src\\css\\custom.css'),
];
