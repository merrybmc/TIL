---
description: Create a doc page with rich content.
---

# intro

merrybmc의 TIL 기록 블로그입니다. 😀

<!-- :::info 목차

Intro
Why Vue.js?
Concepts of Vue.js
:::

:::tip [참고] Evan You 에 의해 발표 (2014)

구글의 Angular 개발자 출신 .
학사 미술, 미술사 전공/석사 디자인 & 테크놀로지 전공
구글 Angular보다 더 가볍고, 간편하게 사용할 수 있는 프레임워크를 만들기 위해 개발
::: -->
